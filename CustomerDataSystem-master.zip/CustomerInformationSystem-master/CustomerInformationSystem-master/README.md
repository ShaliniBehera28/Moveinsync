# StudentInformationSystem
Building a REST Service with Spring Boot and MongoDB

This source code's tutorials: 

https://medium.com/@yigitcannalci/building-a-rest-service-with-spring-boot-and-mongodb-part-1-2de01e4f434d
https://medium.com/@yigitcannalci/writing-a-unit-test-using-spring-boot-part-2-b16847484cb9

Note: If you want to save data using Postman, you can use the sample data in the data.json file.
